"""Stage 2 — turn the SA listing JSON into an Excel workbook.

For each listing row we re-issue POSTs to the same endpoint with different
DataObject names, fetching every child section the detail page exposes:

    DAPRegisterDetail   -> Status, Public Notification, DevId
    Summary             -> Application number, Applicants, Assessment Pathway, Elements
    PropertyDetails     -> Council area
    LandDetails         -> parcel info
    ChildLandDetails    -> parcel info (subdivisions)
    ConsentSummary      -> per-consent status
    ConsentDetails      -> per-consent decision date, authority, contact, public notification
    DecisionDocument    -> PDF links (filename + URL only — no download)
    PublicNoticeData    -> consultation period
    BuildingWorksData   -> building works dates / classifications

Rate-limit handling
-------------------
The endpoint sits behind Cloudflare. To stay polite:

    * Respect 429/503 Retry-After headers when present.
    * Read RFC 9331-style `RateLimit` / `RateLimit-Remaining` / `RateLimit-Reset`
      headers when emitted; slow down when remaining is low.
    * Treat a 403 with a Cloudflare 'Just a moment...' body as a transient block
      and exponential-backoff up to a cap.

Setup:
    python3 -m pip install --user curl_cffi pandas openpyxl

Run:
    python3 /Users/sudhanshu/sa/plansa_extract_to_excel.py
"""

from __future__ import annotations

import argparse
import base64
import json
import re
import sys
import time
from pathlib import Path
from typing import Any

import pandas as pd
from curl_cffi import requests

# ---- Config ---------------------------------------------------------------

SEARCH_URL = "https://cdn.plan.sa.gov.au/prs/dGr64_Jl3Qw"
DEFAULT_JSON_DIR = Path(__file__).resolve().parent / "plansa_data"

IMPERSONATE = "chrome131"
TIMEOUT_S = 30
RETRIES = 5

# Pacing — conservative because the SA WAF rate-limits in short bursts.
SLEEP_BETWEEN_CALLS_S = 1.5    # between sibling calls within one record
SLEEP_BETWEEN_RECORDS_S = 3.0  # at the end of each record's enrichment
RATE_LIMIT_LOW_REMAINING = 3   # if RateLimit-Remaining drops to or below this, slow down extra
RATE_LIMIT_LOW_PAUSE_S = 5     # extra pause when remaining is low
CF_403_BACKOFFS_S = (10, 20, 40, 90, 180)  # exponential backoff for Cloudflare blocks

# Write the Excel workbook every BATCH_WRITE_SIZE records. With 279k+
# records in the SA register and Cloudflare prone to rate-blocking long
# runs, the batch size is a tradeoff:
#   too small  → many full-workbook rewrites (each batch rewrites the
#                whole .xlsx since openpyxl has no append mode)
#   too large  → losing more enriched records on a mid-run block
# 25,000 = 25 listing pages at PAGE_SIZE=1000 — flush roughly every hour
# of enrichment work; 11 flushes total for the full register. CLI override:
# --batch-size N.
BATCH_WRITE_SIZE = 25000

CHILDREN = [
    "Summary",
    "PropertyDetails",
    "LandDetails",
    "ChildLandDetails",
    "ConsentSummary",
    "ConsentDetails",
    "DecisionDocument",
    "PublicNoticeData",
    "BuildingWorksData",
]

HEADERS = {
    "accept": "application/json, text/javascript, */*; q=0.01",
    "accept-language": "en-US,en;q=0.9",
    "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
    "origin": "https://plan.sa.gov.au",
    "referer": "https://plan.sa.gov.au/",
    "sec-fetch-site": "same-site",
    "sec-fetch-mode": "cors",
    "sec-fetch-dest": "empty",
}

# ---- Helpers --------------------------------------------------------------

A_HREF_RE = re.compile(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', flags=re.I | re.S)
A_HREF_URL_RE = re.compile(r'<a[^>]+href="([^"]+)"', flags=re.I)
CF_BODY_MARKER = "Just a moment"


def _is_pdf_url(url: str) -> bool:
    """Treat as PDF when the URL references a .pdf file.

    SA-specific quirk: many PDF links don't expose the .pdf in the path —
    they hit `/assets/get_document?docType=...&filename=Foo.pdf` instead.
    So we check the full URL (path + query) for '.pdf', not just the path.
    """
    u = (url or "").lower()
    if not u:
        return False
    if "/pdf/" in u.split("?", 1)[0]:
        return True
    return ".pdf" in u


def _row_title_hint(section: str, row: dict) -> str:
    """Best-effort human-readable title for a link found in a section row.
    Different sections expose different label fields — use what's available."""
    if section == "DecisionDocument":
        bits = [row.get("Document type") or "", row.get("Date") or ""]
        return " ".join(b for b in bits if b).strip()
    if section == "BuildingWorksData":
        return (row.get("Stage") or row.get("Document type") or "").strip()
    if section == "ConsentDetails":
        return (row.get("ConsentTypeShortName") or row.get("Date") or "").strip()
    if section == "PublicNoticeData":
        return (row.get("Period") or row.get("Status") or "").strip()
    # Generic fallback — first non-empty string field on the row.
    for v in row.values():
        if isinstance(v, str) and v and "<" not in v:
            return v[:80].strip()
    return ""


def harvest_detail_links(sections: dict[str, list[dict]]) -> tuple[list[dict], list[dict]]:
    """Walk every child section / row / field and harvest all <a href> URLs.

    Returns (pdf_links, all_links):
      pdf_links — list[dict] of PDF-only entries, deduped by URL
      all_links — list[dict] of every unique URL found anywhere, deduped by URL

    Each entry: {url, title, section}. Order preserved by first occurrence.
    """
    pdf_seen: set[str] = set()
    pdf_out: list[dict] = []
    all_seen: set[str] = set()
    all_out: list[dict] = []

    for section, rows in (sections or {}).items():
        if not rows:
            continue
        for row in rows:
            if not isinstance(row, dict):
                continue
            for value in row.values():
                if not isinstance(value, str) or "href" not in value.lower():
                    continue
                for m in A_HREF_URL_RE.finditer(value):
                    url = m.group(1).strip()
                    if not url:
                        continue
                    entry = {"url": url, "title": _row_title_hint(section, row), "section": section}
                    if url not in all_seen:
                        all_seen.add(url)
                        all_out.append(entry)
                    if _is_pdf_url(url) and url not in pdf_seen:
                        pdf_seen.add(url)
                        pdf_out.append(entry)
    return pdf_out, all_out


def _strip_tags(s: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", s)).strip()


def _envelope(data_object: str, app_id: str, base: str) -> dict:
    return {
        "ActionType": "select",
        "Config": "public_register",
        "DataObject": data_object,
        "Params": [
            {"name": "AppId", "value": str(app_id)},
            {"name": "Base", "value": str(base)},
        ],
        "SortDirection": "",
        "SortCode": "desc",
        "RecordNumber": 1,
        "MaxRecords": 50,
    }


def _maybe_int(v: str | None) -> int | None:
    try:
        return int(v) if v is not None and v != "" else None
    except (TypeError, ValueError):
        return None


def _ratelimit_pause(headers) -> float:
    """Translate RFC 9331-style RateLimit hints into a polite pause.

    Returns extra seconds to sleep if quota looks tight; 0 otherwise.
    Looks at the 'RateLimit' (combined) and per-bucket headers, case-insensitively.
    """
    # Combined header: 'limit=10, remaining=2, reset=30'
    combined = headers.get("RateLimit") or headers.get("ratelimit")
    if combined:
        m_rem = re.search(r"remaining=(\d+)", combined, re.I)
        m_reset = re.search(r"reset=(\d+)", combined, re.I)
        rem = int(m_rem.group(1)) if m_rem else None
        reset = int(m_reset.group(1)) if m_reset else None
        if rem is not None and rem <= RATE_LIMIT_LOW_REMAINING:
            return float(reset or RATE_LIMIT_LOW_PAUSE_S)

    # Per-bucket variants
    rem = _maybe_int(headers.get("RateLimit-Remaining") or headers.get("X-RateLimit-Remaining"))
    reset = _maybe_int(headers.get("RateLimit-Reset") or headers.get("X-RateLimit-Reset"))
    if rem is not None and rem <= RATE_LIMIT_LOW_REMAINING:
        return float(reset or RATE_LIMIT_LOW_PAUSE_S)
    return 0.0


def post_data_object(data_object: str, app_id: str, base: str) -> dict:
    """Rate-limit-aware POST. Honors Retry-After, RateLimit, and CF 403 backoff."""
    body = base64.b64encode(json.dumps(_envelope(data_object, app_id, base)).encode()).decode()
    last_err: Exception | None = None
    cf_block_count = 0

    for attempt in range(1, RETRIES + 1):
        try:
            r = requests.post(
                SEARCH_URL,
                headers=HEADERS,
                data={"payload": body},
                impersonate=IMPERSONATE,
                timeout=TIMEOUT_S,
                verify=False,
            )

            # Retry-After is the gold standard.
            ra = r.headers.get("Retry-After") or r.headers.get("retry-after")
            if r.status_code in (429, 503) and ra:
                try:
                    secs = int(ra)
                except ValueError:
                    secs = 30
                print(f"  [rate] {data_object} {app_id}: server says Retry-After {secs}s", flush=True)
                time.sleep(min(secs, 300))
                continue

            ct = (r.headers.get("content-type") or "").lower()

            if r.status_code == 200 and "json" in ct:
                # Polite slowdown if quota is tight.
                extra = _ratelimit_pause(r.headers)
                if extra:
                    print(f"  [rate] {data_object} {app_id}: low quota; pausing {extra:.0f}s", flush=True)
                    time.sleep(extra)
                return r.json()

            # Cloudflare challenge / WAF block path.
            if r.status_code in (403, 429, 503) or CF_BODY_MARKER in r.text[:300]:
                cf_block_count += 1
                wait = CF_403_BACKOFFS_S[min(cf_block_count - 1, len(CF_403_BACKOFFS_S) - 1)]
                print(f"  [rate] {data_object} {app_id}: blocked (status={r.status_code}); backoff {wait}s", flush=True)
                time.sleep(wait)
                continue

            # Anything else — log a snippet and bail this attempt.
            snippet = r.text[:200].replace("\n", " ")
            raise RuntimeError(f"status={r.status_code} ct={ct} body={snippet!r}")
        except Exception as e:
            last_err = e
            if attempt < RETRIES:
                wait = 2 * attempt
                print(f"  [retry] {data_object} {app_id}: {e}; sleep {wait}s", flush=True)
                time.sleep(wait)

    raise RuntimeError(f"giving up on {data_object} for {app_id}: {last_err}")


def labelled_rows(envelope: dict) -> list[dict[str, Any]]:
    """Translate a generic envelope into rows keyed by FieldLabel."""
    schema = envelope.get("Fields", {}).get("Fields", []) or []
    labels = [f.get("FieldLabel") or f.get("FieldCode") or f"col_{i}" for i, f in enumerate(schema)]
    out: list[dict[str, Any]] = []
    for v in envelope.get("Values") or []:
        fv = list(v.get("FieldValues") or [])
        fv += [""] * (len(labels) - len(fv))
        out.append(dict(zip(labels, fv)))
    return out


# ---- Per-record enrichment ------------------------------------------------


def enrich_record(app_id: str, base: str) -> dict[str, list[dict]]:
    """Fetch DAPRegisterDetail; harvest all 9 children from the same response.

    The master response embeds every child envelope inline at:
        Values[0].ChildQueries  =  [{Key: <ChildName>, Value: <full envelope>}, ...]

    so a single POST gives us everything (10x speed-up vs sibling calls).
    """
    master = post_data_object("DAPRegisterDetail", app_id, base)
    out: dict[str, list[dict]] = {"DAPRegisterDetail": labelled_rows(master)}

    values = master.get("Values") or []
    if values:
        for q in values[0].get("ChildQueries") or []:
            key = q.get("Key")
            env = q.get("Value") or {}
            if not key:
                continue
            try:
                out[key] = labelled_rows(env)
            except Exception as e:
                print(f"  [warn] parsing child {key} for {app_id}: {e}", flush=True)
                out[key] = []

    # Make sure every expected child has a key (empty list if absent), so
    # downstream code doesn't have to guard.
    for child in CHILDREN:
        out.setdefault(child, [])

    return out


# ---- Date / value shaping -------------------------------------------------


def normalise_lodged(s: str) -> str:
    """SA listing 'Lodged' is dd/mm/yyyy. Convert to YYYY-MM-DD."""
    if not s:
        return ""
    m = re.match(r"^\s*(\d{1,2})/(\d{1,2})/(\d{4})", s)
    if not m:
        return s
    d, mo, y = m.groups()
    return f"{y}-{int(mo):02d}-{int(d):02d}"


def normalise_doc_date(s: str) -> str:
    """'09 May 2026' -> '2026-05-09'. Returns the original string on parse failure."""
    if not s:
        return ""
    s = s.strip()
    for fmt in ("%d %b %Y", "%d %B %Y", "%d/%m/%Y", "%Y-%m-%d"):
        try:
            return time.strftime("%Y-%m-%d", time.strptime(s, fmt))
        except ValueError:
            continue
    return s


# ---- Build rows -----------------------------------------------------------


def iter_rows(records: list[dict], skip_detail: bool = False):
    """Yield one assembled row dict per record.

    Generator form so the caller can write the workbook incrementally
    (every BATCH_WRITE_SIZE rows) instead of waiting for the whole run.

    Output schema is the SA Combined Plan's Mode B set + Date Submitted
    (recoverable from the JSON listing — `Lodged`) and PDF Links. Phased
    approvals are preserved as a JSON column plus four denormalised columns:
    latest_approval_date, latest_stage, approval_count, all_approval_dates_concat.
    """
    for i, r in enumerate(records, 1):
        app_id = str(r.get("ID") or "")
        base = str(r.get("Register Code") or "DAP")
        applicant_listing = r.get("Applicant", "")
        address_listing = r.get("Property address", "")
        lodged_listing = normalise_lodged(r.get("Lodged", ""))
        # import ipdb;ipdb.set_trace()
        if skip_detail or not app_id:
            sections: dict[str, list[dict]] = {}
        else:
            print(f"[{i}/{len(records)}] enriching {base} {app_id}", flush=True)
            try:
                sections = enrich_record(app_id, base)
            except Exception as e:
                print(f"  [error] enrichment failed for {app_id}: {e}", flush=True)
                sections = {}
            time.sleep(SLEEP_BETWEEN_RECORDS_S)

        det = (sections.get("DAPRegisterDetail") or [{}])[0]
        summary = (sections.get("Summary") or [{}])[0]
        prop = (sections.get("PropertyDetails") or [{}])[0]

        # ---- Phased approvals (Plan §5 — list of (stage_name, decision_date)) ----
        # Keep only entries where a real decision date is present.
        phased: list[dict[str, str]] = []
        for c in sections.get("ConsentDetails") or []:
            stage = (c.get("ConsentTypeShortName") or "").strip()
            cdate = (c.get("Date") or "").strip()
            d_iso = normalise_doc_date(cdate) if cdate and cdate != "-" else ""
            if not stage or not d_iso:
                continue
            phased.append({"stage_name": stage, "decision_date": d_iso})

        approval_count = len(phased)
        all_dates_iso = sorted({p["decision_date"] for p in phased})
        latest_approval_date = max(all_dates_iso) if all_dates_iso else ""
        latest_stage = ""
        for p in phased:
            if p["decision_date"] == latest_approval_date:
                latest_stage = p["stage_name"]
                break
        all_dates_concat = "; ".join(all_dates_iso)

        # ---- All hyperlinks in the detail JSON (every child section) ----
        pdf_links, all_links = harvest_detail_links(sections)
        pdf_lines = [
            f"[{p['section']}] {p['title']} — {p['url']}".replace("[]", "[detail]")
            if not p.get("title") else f"[{p['section']}] {p['title']} — {p['url']}"
            for p in pdf_links
        ]
        all_link_lines = [
            f"[{p['section']}] {p['title']} — {p['url']}" if p.get("title")
            else f"[{p['section']}] {p['url']}"
            for p in all_links
        ]

        # ---- Application Number with the "DAP" prefix preserved ----
        def _real(v: str) -> str:
            v = (v or "").strip()
            return "" if v.upper() in ("", "N/A", "-") else v
        app_no = (
            _real(det.get("Application number", ""))
            or _real(summary.get("Application number", ""))
            or f"{base} {app_id}"
        )

        # Date Submitted — Plan §4.5 says Mode B loses this for SA because the
        # plan assumed the VerificationOutcome PDF was the only source. The
        # listing JSON we use exposes it directly via `Lodged`, so the field
        # is recoverable on the JSON path. Falls back to Summary.Lodged.
        date_submitted = lodged_listing or normalise_doc_date(summary.get("Lodged", ""))

        yield {
            "Authority": prop.get("Council area", ""),
            "Address": address_listing or det.get("Address", ""),
            "Application Number": app_no,
            "Date Submitted": date_submitted,
            "Developer": applicant_listing or summary.get("Applicants", ""),
            "Status": det.get("Status", ""),
            "latest_approval_date": latest_approval_date,
            "latest_stage": latest_stage,
            "approval_count": approval_count,
            "all_approval_dates_concat": all_dates_concat,
            "phased_approvals": json.dumps(phased, ensure_ascii=False) if phased else "",
            "PDF Count": len(pdf_links),
            "PDF Links": "\n".join(pdf_lines),
            "All Detail Links": "\n".join(all_link_lines),
        }


# ---- Excel writer ---------------------------------------------------------


def write_excel(rows: list[dict], out_path: Path) -> None:
    df = pd.DataFrame(rows)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(out_path, engine="openpyxl") as xw:
        df.to_excel(xw, sheet_name="plansa_register", index=False)
        ws = xw.sheets["plansa_register"]

        widths = {
            "Authority": 24,
            "Address": 50,
            "Application Number": 18,
            "Date Submitted": 14,
            "Developer": 30,
            "Status": 22,
            "latest_approval_date": 18,
            "latest_stage": 22,
            "approval_count": 13,
            "all_approval_dates_concat": 30,
            "phased_approvals": 60,
            "PDF Count": 11,
            "PDF Links": 80,
            "All Detail Links": 80,
        }
        from openpyxl.utils import get_column_letter  # type: ignore
        from openpyxl.styles import Alignment        # type: ignore

        for idx, col in enumerate(df.columns, start=1):
            ws.column_dimensions[get_column_letter(idx)].width = widths.get(col, 20)

        wrap_cols = {"PDF Links", "All Detail Links", "Address", "phased_approvals", "all_approval_dates_concat"}
        for idx, col in enumerate(df.columns, start=1):
            if col not in wrap_cols:
                continue
            letter = get_column_letter(idx)
            for row_i in range(2, len(df) + 2):
                ws[f"{letter}{row_i}"].alignment = Alignment(wrap_text=True, vertical="top")

        ws.freeze_panes = "A2"


# ---- Main -----------------------------------------------------------------


def newest_json(dirp: Path) -> Path:
    cands = sorted(dirp.glob("results_*.json"))
    if not cands:
        raise FileNotFoundError(f"no results_*.json under {dirp}")
    return cands[-1]


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--json", type=Path, default=None, help="path to results_*.json (default: newest under plansa_data/)")
    ap.add_argument("--out", type=Path, default=None, help="output xlsx (default: plansa_data/plansa_register_<date>.xlsx)")
    ap.add_argument("--skip-detail", action="store_true", help="skip the per-record detail/property/document POSTs")
    ap.add_argument("--batch-size", type=int, default=BATCH_WRITE_SIZE,
                    help=f"write the workbook every N processed rows (default: {BATCH_WRITE_SIZE}). "
                         f"Set to 0 to disable incremental writes.")
    args = ap.parse_args(argv)

    json_path = args.json or newest_json(DEFAULT_JSON_DIR)
    out_path = args.out or (DEFAULT_JSON_DIR / f"plansa_register_{time.strftime('%Y-%m-%d')}.xlsx")
    batch_size = max(0, args.batch_size)

    print(f"[load] {json_path}", flush=True)
    
    raw = json.loads(json_path.read_text(encoding="utf-8"))

    # Keep only records where Description contains 'Data'
    filtered_rows = [
    row
    for row in raw.get("rows", [])
    if "data" in str(row.get("Description", "")).lower()
    ]
    raw=filtered_rows
    # import ipdb;ipdb.set_trace()
    # Tolerate two listing-JSON shapes:
    #   - list                                          (legacy unfiltered run)
    #   - {"rows": [...], "params": {...}, ...}         (filtered run, current)
    if isinstance(raw, dict) and "rows" in raw:
        records = raw["rows"]
        if raw.get("params"):
            print(f"[load] listing filters: {raw['params']}", flush=True)
    else:
        records = raw
    print(f"[load] {len(records)} listing rows", flush=True)

    rows: list[dict] = []
    last_written_at = 0
    try:
        for i, row in enumerate(iter_rows(records, skip_detail=args.skip_detail), 1):
            rows.append(row)
            # Flush after every full batch — so the workbook is usable as soon
            # as the first BATCH_WRITE_SIZE records are ready.
            if batch_size and i % batch_size == 0:
                write_excel(rows, out_path)
                last_written_at = i
                print(f"[batch] wrote {len(rows)} rows -> {out_path}", flush=True)
    except KeyboardInterrupt:
        print(f"\n[abort] interrupted after {len(rows)} rows; writing partial workbook…", flush=True)

    if not rows:
        print("[error] no rows to write", file=sys.stderr)
        return 1

    # Final write for any trailing partial batch (or if batching was disabled).
    if last_written_at != len(rows):
        write_excel(rows, out_path)
        print(f"[final] wrote {len(rows)} rows -> {out_path}", flush=True)

    filled = {
        col: sum(1 for r in rows if r[col])
        for col in ("Authority", "Address", "Application Number", "Date Submitted",
                    "Developer", "Status", "latest_approval_date",
                    "phased_approvals", "PDF Count", "PDF Links", "All Detail Links")
    }
    print(f"[done] fill rates: {filled}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
