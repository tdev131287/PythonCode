"""End-to-end runner: FULL pipeline (listing + per-record detail + Excel).

This is the slow, comprehensive path. For each listing record it makes one
extra POST to the same endpoint to harvest the master detail envelope
(which inlines every child section: Summary, PropertyDetails, ConsentDetails,
DecisionDocument, etc.) and writes the enriched workbook
`plansa_register_<date>.xlsx` with 12 columns.

Two stages, chained:
  1. plansa_scraper.py            — fetch listing JSON  (results_<date>.json)
  2. plansa_extract_to_excel.py   — per-record detail POST + Excel assembly
                                    (plansa_register_<date>.xlsx)

Both stages remain independently runnable. This wrapper just chains them.

Wall-clock cost
---------------
With pacing tuned for SA's WAF, full register (~280k records) takes
roughly nine days. Use `plansa_run_listing.py` instead for a listing-only
view (~5 hours for the same 280k records).

Run:
    python3 /Users/sudhanshu/sa/plansa_run_full.py

Bound to a few pages for a quick sample (the --max-pages flag is consumed
by the inner scraper):
    python3 /Users/sudhanshu/sa/plansa_run_full.py --max-pages 5
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import plansa_scraper as scraper           # noqa: E402
import plansa_extract_to_excel as extractor  # noqa: E402


def _stamp() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def main(argv: list[str] | None = None) -> int:
    """Chain scraper -> extractor. All argv are passed through to the scraper
    (so --keyword / --lodged-from / --max-pages / --start-page / --no-resume
    work end-to-end); the extractor always uses its defaults since it reads
    whatever the scraper produced."""
    started = time.time()
    print(f"[run] start {_stamp()}", flush=True)

    print("[run] step 1/2 — fetch listing JSON", flush=True)
    rc = scraper.main(argv)
    if rc != 0:
        print(f"[run] step 1 failed (rc={rc}); skipping step 2", flush=True)
        return rc

    print("[run] step 2/2 — build register Excel", flush=True)
    rc = extractor.main([])
    if rc != 0:
        print(f"[run] step 2 failed (rc={rc})", flush=True)
        return rc

    print(f"[run] done {_stamp()} ({time.time() - started:.1f}s)", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
