"""End-to-end runner: LISTING-ONLY pipeline (no detail-page calls).

Fetches every page of the SA Public Register listing endpoint and writes
Excel directly with whatever fields the listing payload exposes. Skips
per-record detail enrichment entirely — no Council, no Status, no
ConsentDetails, no PDF links.

Compared to `plansa_run_full.py` (full enrichment):
    * ~10x fewer requests (1 listing POST per 25 records, vs 1 listing
      POST per 25 + 1 detail POST per record).
    * ~10x faster end-to-end. Full register (~280k records, 11k listing
      pages) is roughly 5 hours instead of ~9 days.
    * Output is narrower: only the columns the listing actually exposes.

Output columns (everything the listing exposes that's worth keeping):
    Application Number     "<Register Code> <ID>" (preserves DAP prefix)
    Address                Property address
    Date Submitted         Lodged, normalised to YYYY-MM-DD
    Developer              Applicant
    Description            DevDesc
    Reference Number       DevNo (often blank for fresh permits)
    App ID                 raw ID for audit / cross-reference

Incremental writes
------------------
Workbook is rewritten every BATCH_WRITE_SIZE rows (default 25,000 — i.e.
every 25 listing pages at PAGE_SIZE=1000). A long multi-page run produces
a usable file after the first batch and survives mid-run Cloudflare
blocks. Listing JSON is also flushed after every page so raw rows are
never lost.

Setup:
    python3 -m pip install --user curl_cffi pandas openpyxl

Run (full register, ~5h):
    python3 /Users/sudhanshu/sa/plansa_run_listing.py

Run (limit to N listing pages for a quick sample):
    python3 /Users/sudhanshu/sa/plansa_run_listing.py --max-pages 5
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import time
from pathlib import Path

import pandas as pd

# Reuse the listing fetcher from the main scraper.
HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import plansa_scraper as scraper  # noqa: E402

# ---- Config ---------------------------------------------------------------

OUT_DIR = scraper.OUT_DIR

# See plansa_extract_to_excel.py for the rationale; same default.
BATCH_WRITE_SIZE = 25000

LODGED_RE = re.compile(r"^\s*(\d{1,2})/(\d{1,2})/(\d{4})")


def normalise_lodged(s: str) -> str:
    """SA listing 'Lodged' is dd/mm/yyyy. Convert to YYYY-MM-DD."""
    if not s:
        return ""
    m = LODGED_RE.match(s)
    if not m:
        return s
    d, mo, y = m.groups()
    return f"{y}-{int(mo):02d}-{int(d):02d}"


def to_excel_row(r: dict) -> dict:
    app_id = (r.get("ID") or "").strip()
    base = (r.get("Register Code") or "DAP").strip()
    return {
        "Application Number": f"{base} {app_id}".strip() if app_id else "",
        "Address": r.get("Property address", ""),
        "Date Submitted": normalise_lodged(r.get("Lodged", "")),
        "Developer": r.get("Applicant", ""),
        "Description": r.get("Description", ""),
        "Reference Number": r.get("Reference number", ""),
        "App ID": app_id,
    }


def write_excel(rows: list[dict], out_path: Path) -> None:
    df = pd.DataFrame(rows)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(out_path, engine="openpyxl") as xw:
        df.to_excel(xw, sheet_name="plansa_listing", index=False)
        ws = xw.sheets["plansa_listing"]

        widths = {
            "Application Number": 18,
            "Address": 50,
            "Date Submitted": 14,
            "Developer": 30,
            "Description": 60,
            "Reference Number": 18,
            "App ID": 12,
        }
        from openpyxl.utils import get_column_letter  # type: ignore
        from openpyxl.styles import Alignment        # type: ignore

        for idx, col in enumerate(df.columns, start=1):
            ws.column_dimensions[get_column_letter(idx)].width = widths.get(col, 20)

        wrap_cols = {"Address", "Description"}
        for idx, col in enumerate(df.columns, start=1):
            if col not in wrap_cols:
                continue
            letter = get_column_letter(idx)
            for row_i in range(2, len(df) + 2):
                ws[f"{letter}{row_i}"].alignment = Alignment(wrap_text=True, vertical="top")

        ws.freeze_panes = "A2"


def write_listing_state(state: dict, out_path: Path) -> None:
    """Per-page state flush. Writes the new state-shaped JSON
    {"rows": [...], "last_page_fetched": N, "params": {...}} so a mid-run
    block doesn't lose progress, and resume can match filter params."""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", type=Path, default=None,
                    help="output xlsx (default: plansa_data/plansa_listing_<date>.xlsx)")
    ap.add_argument("--max-pages", type=int, default=None,
                    help="limit listing pages fetched (default: all available)")
    ap.add_argument("--batch-size", type=int, default=BATCH_WRITE_SIZE,
                    help=f"write workbook every N rows (default: {BATCH_WRITE_SIZE}); 0 = only at end")
    ap.add_argument("--start-page", type=int, default=None,
                    help="manual override of the starting page (default: auto-resume)")
    ap.add_argument("--no-resume", action="store_true",
                    help="ignore any existing plansa_listing_<date>.json and start from page 1")
    ap.add_argument("--keyword", default=scraper.DEFAULT_KEYWORD,
                    help=f"comma-separated keywords; rows whose Description doesn't match any "
                         f"keyword (case-insensitive) are dropped before persistence. "
                         f"Empty string disables the filter. Default: {scraper.DEFAULT_KEYWORD!r}")
    ap.add_argument("--lodged-from", default=scraper.DEFAULT_LODGED_FROM,
                    help=f"YYYY-MM-DD or dd/MM/yyyy; sent to the server as LodgedDateStart. "
                         f"Empty string disables the date floor. Default: {scraper.DEFAULT_LODGED_FROM!r}")
    args = ap.parse_args(argv)

    today = time.strftime("%Y-%m-%d")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = args.out or (OUT_DIR / f"plansa_listing_{today}.xlsx")
    raw_json_path = OUT_DIR / f"plansa_listing_{today}.json"
    batch_size = max(0, args.batch_size)

    # Configure the scraper's server-side date filter and build the keyword list.
    scraper.set_lodged_from(args.lodged_from)
    needles = scraper.parse_keywords(args.keyword)
    expected_params = {"keyword": args.keyword or "", "lodged_from": args.lodged_from or ""}

    label = []
    if args.lodged_from:
        label.append(f"Lodged≥{args.lodged_from}")
    if needles:
        label.append(f"Description contains {'|'.join(needles)}")
    if label:
        print(f"[filter] {' AND '.join(label)}", flush=True)

    state = scraper._load_state(raw_json_path, expected_params)
    raw_rows: list[dict] = state["rows"]
    excel_rows: list[dict] = [to_excel_row(r) for r in raw_rows]
    last_written = 0
    page = state["last_page_fetched"] + 1
    total_records = 0

    if args.start_page is not None:
        page = max(1, args.start_page)
        state["last_page_fetched"] = page - 1
        print(f"[resume] --start-page override: starting at page {page}", flush=True)

    try:
        while True:
            print(f"[fetch] page={page}", flush=True)
            envelope = scraper.fetch_page(page)
            page_rows, total_records = scraper.rows_from_envelope(envelope)
            if not page_rows:
                break

            kept = [r for r in page_rows if scraper.keyword_matches(r, needles)] if needles else page_rows
            raw_rows.extend(kept)
            for r in kept:
                excel_rows.append(to_excel_row(r))
            state["last_page_fetched"] = page

            print(
                f"  +{len(page_rows)} raw, +{len(kept)} kept "
                f"(running {len(excel_rows)}; server total {total_records})",
                flush=True,
            )

            # Per-page state snapshot (cheap, gives an audit trail).
            write_listing_state(state, raw_json_path)

            # Excel only every BATCH_WRITE_SIZE rows — rewriting the whole
            # workbook every page would be wasteful when the filter is off.
            if batch_size and (len(excel_rows) - last_written) >= batch_size:
                write_excel(excel_rows, out_path)
                last_written = len(excel_rows)
                print(f"[batch] wrote {len(excel_rows)} rows -> {out_path}", flush=True)

            if args.max_pages is not None and page >= args.max_pages:
                break
            if total_records and page * scraper.PAGE_SIZE >= total_records:
                break
            if len(page_rows) < scraper.PAGE_SIZE:
                break

            page += 1
            time.sleep(scraper.SLEEP_BETWEEN_PAGES_S)
    except KeyboardInterrupt:
        print(f"\n[abort] interrupted at page {page}; preserving {len(excel_rows)} rows", flush=True)

    # Final flush for any trailing partial batch (or batching disabled).
    if excel_rows and last_written != len(excel_rows):
        write_excel(excel_rows, out_path)
        print(f"[final] wrote {len(excel_rows)} rows -> {out_path}", flush=True)
    write_listing_state(state, raw_json_path)

    if not excel_rows:
        print("[error] no rows written", file=sys.stderr)
        return 1

    filled = {
        col: sum(1 for r in excel_rows if r[col])
        for col in ("Application Number", "Address", "Date Submitted",
                    "Developer", "Description", "Reference Number")
    }
    print(f"[done] {len(excel_rows)} rows; fill rates: {filled}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
