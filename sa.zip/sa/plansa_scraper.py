"""Stage 1 — fetch the SA Public Register listing JSON.

Endpoint behaviour (reverse-engineered from a captured browser request):

    POST https://cdn.plan.sa.gov.au/prs/dGr64_Jl3Qw
    Content-Type: application/x-www-form-urlencoded; charset=UTF-8
    Body: payload=<base64( JSON request envelope )>

The base64-decoded request envelope looks like:

    {
      "ActionType":     "select",
      "Config":         "public_register",
      "DataObject":     "PublicRegisterSearch",
      "Params":         [{"name":"Page","value":"1"},
                         {"name":"PageSize","value":"25"}],
      "SortDirection":  "",
      "SortExpression": "LodgedNew",
      "RecordNumber":   0,
      "MaxRecords":     25
    }

The response is a generic data-grid envelope with two interesting parts:
  - Fields.Fields[]    schema (column names, types, labels)
  - Values[]           rows; each row is {ChildQueries:[], FieldValues:[v0,v1,...]}
                       where FieldValues are positionally aligned to Fields.Fields[].

This script:
  1. POSTs page 1 only (configurable via MAX_PAGES below).
  2. Decodes Values into a list of dicts keyed by FieldLabel.
  3. Writes results_<date>.json + results_<date>.csv next to this script.

Setup:
    python3 -m pip install --user curl_cffi

Run:
    python3 /Users/sudhanshu/sa/plansa_scraper.py
"""

from __future__ import annotations

import base64
import csv
import json
import re
import sys
import time
from pathlib import Path
from typing import Any

from curl_cffi import requests

# ---- Config ---------------------------------------------------------------

SEARCH_URL = "https://cdn.plan.sa.gov.au/prs/dGr64_Jl3Qw"
PARENT_PAGE = "https://plan.sa.gov.au/development_application_register"

# Records per listing request. The browser's UI sends 25, but the server
# accepts anything we ask for (probed up to 10,000 with no cap). 1,000 is
# the sweet spot: ~250 KB response, ~1 s per call, 40x fewer calls than 25.
# Push higher (e.g. 5000–10000) only if you're not chaining many runs and
# want to shave further at the cost of a more conspicuous request.
PAGE_SIZE = 1000

# Default: None = fetch every page until the server stops returning rows.
# Override at runtime with `--max-pages N` to test or limit.
MAX_PAGES: int | None = None

# Filters that scope the run to data-centre-relevant SA lodgements.
# The server accepts `LodgedDateStart` (dd/MM/yyyy) — confirmed via the
# PublicRegisterFields schema. `LodgedDateEnd` is exposed in the schema
# but silently breaks when paired with start, so we don't send it.
# No server-side description filter exists, so the keyword is applied
# client-side against each row's `Description` field.
DEFAULT_KEYWORD = ""
DEFAULT_LODGED_FROM = "2023-01-01"

# Mutable module state — `build_payload` reads this so we can keep the
# existing per-page fetcher signature unchanged.
_LODGED_FROM_DDMMYYYY: str = ""

OUT_DIR = Path(__file__).resolve().parent / "plansa_data"
IMPERSONATE = "chrome131"
TIMEOUT_S = 30
RETRIES = 6                    # was 3; CF challenges sometimes need more attempts
SLEEP_BETWEEN_PAGES_S = 2.0    # was 1.0; lower request rate avoids tripping the WAF

# Rate-limit / Cloudflare-block handling (matches the extractor)
RATE_LIMIT_LOW_REMAINING = 3
RATE_LIMIT_LOW_PAUSE_S = 5
CF_403_BACKOFFS_S = (10, 20, 40, 90, 180, 360)
CF_BODY_MARKER = "Just a moment"

HEADERS = {
    "accept": "application/json, text/javascript, */*; q=0.01",
    "accept-language": "en-US,en;q=0.9",
    "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
    "origin": "https://plan.sa.gov.au",
    "referer": "https://plan.sa.gov.au/",
    "sec-fetch-site": "same-site",
    "sec-fetch-mode": "cors",
    "sec-fetch-dest": "empty",
}


def normalise_date_param(s: str) -> str:
    """Accept YYYY-MM-DD or dd/MM/yyyy; emit dd/MM/yyyy for the envelope."""
    if not s:
        return ""
    s = s.strip()
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})$", s)
    if m:
        y, mo, d = m.groups()
        return f"{int(d):02d}/{int(mo):02d}/{y}"
    m = re.match(r"^(\d{1,2})/(\d{1,2})/(\d{4})$", s)
    if m:
        d, mo, y = m.groups()
        return f"{int(d):02d}/{int(mo):02d}/{y}"
    raise ValueError(f"unrecognised date {s!r}; expected YYYY-MM-DD or dd/MM/yyyy")


def set_lodged_from(value: str) -> None:
    """Configure the server-side LodgedDateStart filter for the rest of the run."""
    global _LODGED_FROM_DDMMYYYY
    _LODGED_FROM_DDMMYYYY = normalise_date_param(value) if value else ""


def build_payload(page: int, page_size: int) -> str:
    """Return the base64(JSON) string the server expects in the form 'payload=' field."""
    params = [
        {"name": "Page", "value": str(page)},
        {"name": "PageSize", "value": str(page_size)},
    ]
    if _LODGED_FROM_DDMMYYYY:
        params.append({"name": "LodgedDateStart", "value": _LODGED_FROM_DDMMYYYY})
    envelope = {
        "ActionType": "select",
        "Config": "public_register",
        "DataObject": "PublicRegisterSearch",
        "Params": params,
        "SortDirection": "",
        "SortExpression": "LodgedNew",
        "RecordNumber": (page - 1) * page_size,
        "MaxRecords": page_size,
    }
    return base64.b64encode(json.dumps(envelope).encode()).decode()


def keyword_matches(row: dict, needles_lower: list[str]) -> bool:
    """True when `Description` contains any keyword (case-insensitive substring)."""
    if not needles_lower:
        return True
    desc = (row.get("Description") or "").lower()
    return any(n in desc for n in needles_lower)


def parse_keywords(s: str) -> list[str]:
    """Comma-separated keyword string -> lowercase list, empty string -> [] (no filter)."""
    if not s:
        return []
    return [k.strip().lower() for k in s.split(",") if k.strip()]


def _ratelimit_pause(headers) -> float:
    """Translate RFC 9331-style RateLimit hints into a polite extra pause.

    Returns extra seconds to sleep when the server says quota is tight.
    Looks at the combined `RateLimit` header and per-bucket variants.
    """
    combined = headers.get("RateLimit") or headers.get("ratelimit")
    if combined:
        m_rem = re.search(r"remaining=(\d+)", combined, re.I)
        m_reset = re.search(r"reset=(\d+)", combined, re.I)
        rem = int(m_rem.group(1)) if m_rem else None
        reset = int(m_reset.group(1)) if m_reset else None
        if rem is not None and rem <= RATE_LIMIT_LOW_REMAINING:
            return float(reset or RATE_LIMIT_LOW_PAUSE_S)

    rem_raw = headers.get("RateLimit-Remaining") or headers.get("X-RateLimit-Remaining")
    reset_raw = headers.get("RateLimit-Reset") or headers.get("X-RateLimit-Reset")
    try:
        rem_i = int(rem_raw) if rem_raw not in (None, "") else None
    except (TypeError, ValueError):
        rem_i = None
    try:
        reset_i = int(reset_raw) if reset_raw not in (None, "") else None
    except (TypeError, ValueError):
        reset_i = None
    if rem_i is not None and rem_i <= RATE_LIMIT_LOW_REMAINING:
        return float(reset_i or RATE_LIMIT_LOW_PAUSE_S)
    return 0.0


def fetch_page(page: int) -> dict:
    """POST one listing page with rate-limit-aware retries.

    Honours `Retry-After` on 429/503; reads `RateLimit-*` headers to
    self-pace; detects Cloudflare 'Just a moment...' challenge bodies and
    backs off exponentially through CF_403_BACKOFFS_S before retrying.
    """
    body = {"payload": build_payload(page, PAGE_SIZE)}
    last_err: Exception | None = None
    cf_block_count = 0

    for attempt in range(1, RETRIES + 1):
        try:
            r = requests.post(
                SEARCH_URL,
                headers=HEADERS,
                data=body,
                impersonate=IMPERSONATE,
                timeout=TIMEOUT_S,
                verify=False,
            )

            # Server-instructed wait — gold standard.
            ra = r.headers.get("Retry-After") or r.headers.get("retry-after")
            if r.status_code in (429, 503) and ra:
                try:
                    secs = int(ra)
                except ValueError:
                    secs = 30
                print(f"[rate] page={page}: server says Retry-After {secs}s", flush=True)
                time.sleep(min(secs, 600))
                continue

            ct = (r.headers.get("content-type") or "").lower()

            if r.status_code == 200 and "json" in ct:
                extra = _ratelimit_pause(r.headers)
                if extra:
                    print(f"[rate] page={page}: low quota; pausing {extra:.0f}s", flush=True)
                    time.sleep(extra)
                return r.json()

            # Cloudflare challenge / WAF block path.
            if r.status_code in (403, 429, 503) or CF_BODY_MARKER in r.text[:300]:
                cf_block_count += 1
                wait = CF_403_BACKOFFS_S[min(cf_block_count - 1, len(CF_403_BACKOFFS_S) - 1)]
                print(
                    f"[rate] page={page}: blocked (status={r.status_code}); backoff {wait}s",
                    flush=True,
                )
                time.sleep(wait)
                continue

            # Some other unexpected status — log and treat as a transient error.
            snippet = r.text[:200].replace("\n", " ")
            raise RuntimeError(f"status={r.status_code} ct={ct} body={snippet!r}")
        except Exception as e:
            last_err = e
            if attempt < RETRIES:
                wait = 2 * attempt
                print(f"[retry] page={page} attempt={attempt}: {e}; sleep {wait}s", flush=True)
                time.sleep(wait)

    raise RuntimeError(f"giving up at page={page}: {last_err}")


def rows_from_envelope(envelope: dict) -> tuple[list[dict[str, Any]], int]:
    """Return (rows_as_dicts, total_records).

    Each row is keyed by the schema's FieldLabel (so 'Property address', 'Lodged', etc.)
    """
    schema = envelope.get("Fields", {}).get("Fields", []) or []
    labels = [f.get("FieldLabel") or f.get("FieldCode") or f"col_{i}" for i, f in enumerate(schema)]
    raw_values = envelope.get("Values") or []

    total_records = 0
    rows: list[dict[str, Any]] = []
    for v in raw_values:
        fv = v.get("FieldValues") or []
        # Pad/truncate so labels and values stay aligned.
        fv = list(fv) + [""] * (len(labels) - len(fv))
        row = dict(zip(labels, fv))
        # Capture the global TotalRecords if present.
        try:
            total_records = max(total_records, int(row.get("TotalRecords") or 0))
        except (TypeError, ValueError):
            pass
        rows.append(row)
    return rows, total_records


def _load_state(json_path: Path, expected_params: dict) -> dict:
    """Read existing state file. Tolerates two formats:
       - dict  {"rows": [...], "last_page_fetched": N, "params": {...}}  (new)
       - list  [...]                                                       (legacy)

    Returns a fresh state if (a) the file doesn't exist, (b) parsing fails,
    (c) the legacy format is found but filters are now active (the legacy
    JSON predates filtered runs and can't be safely resumed), or (d) the
    saved filter params don't match the current invocation.
    """
    fresh = {"rows": [], "last_page_fetched": 0, "params": expected_params}
    if not json_path.exists():
        return fresh
    try:
        raw = json.loads(json_path.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[resume] couldn't read {json_path.name} ({e}); starting fresh", flush=True)
        return fresh

    if isinstance(raw, list):
        if expected_params.get("keyword") or expected_params.get("lodged_from"):
            print(
                f"[resume] legacy unfiltered JSON found but filters are now active; "
                f"starting fresh (run with --no-resume to silence)",
                flush=True,
            )
            return fresh
        # Legacy unfiltered run — best-effort resume page from row count.
        return {
            "rows": raw,
            "last_page_fetched": len(raw) // PAGE_SIZE,
            "params": expected_params,
        }

    if isinstance(raw, dict):
        saved = raw.get("params") or {}
        if saved.get("keyword", "") != expected_params.get("keyword", "") or \
           saved.get("lodged_from", "") != expected_params.get("lodged_from", ""):
            print(
                f"[resume] saved filters {saved} differ from current "
                f"{expected_params}; starting fresh",
                flush=True,
            )
            return fresh
        rows = raw.get("rows") or []
        last = int(raw.get("last_page_fetched") or 0)
        print(
            f"[resume] loaded {len(rows)} rows from {json_path.name}; "
            f"continuing from page {last + 1}",
            flush=True,
        )
        return {"rows": rows, "last_page_fetched": last, "params": expected_params}

    return fresh


def harvest(
    max_pages: int | None = None,
    start_page: int | None = None,
    resume: bool = True,
    keyword: str = "",
    lodged_from: str = "",
) -> tuple[int, Path, Path]:
    """Fetch listing pages until exhaustion (or until `max_pages` if set).

    `keyword`        comma-separated keywords; rows whose Description doesn't
                     match any keyword (case-insensitive substring) are dropped
                     before persistence. Empty string disables the filter.
    `lodged_from`    YYYY-MM-DD or dd/MM/yyyy; sent to the server as
                     `LodgedDateStart`. Empty string disables the date floor.

    Auto-resume: if `resume=True` and a state file exists with matching
    `keyword` + `lodged_from`, continue from the next page. Manual override
    via `start_page=N`.
    """

    
    if max_pages is None:
        max_pages = MAX_PAGES

    # Configure the server-side date filter for build_payload().
    set_lodged_from(lodged_from)
    needles = parse_keywords(keyword)
    expected_params = {"keyword": keyword or "", "lodged_from": lodged_from or ""}

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    today = time.strftime("%Y-%m-%d")
    json_path = OUT_DIR / f"results_{today}.json"
    csv_path = OUT_DIR / f"results_{today}.csv"

    def flush(state: dict) -> None:
        """Persist state to JSON + CSV (overwrite). Called after every page."""
        json_path.write_text(
            json.dumps(state, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        rows = state.get("rows") or []
        if rows:
            keys = list(rows[0].keys())
            with csv_path.open("w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=keys)
                w.writeheader()
                for row in rows:
                    w.writerow({k: row.get(k, "") for k in keys})

    state = _load_state(json_path, expected_params)
    total_records = 0
    page = state["last_page_fetched"] + 1

    if start_page is not None:
        page = max(1, start_page)
        state["last_page_fetched"] = page - 1
        print(f"[resume] --start-page override: starting at page {page}", flush=True)

    label = []
    if lodged_from:
        label.append(f"Lodged≥{lodged_from}")
    if needles:
        label.append(f"Description contains {'|'.join(needles)}")
    if label:
        print(f"[filter] {' AND '.join(label)}", flush=True)
    
    try:
        while True:
            print(f"[fetch] page={page}", flush=True)
            
            envelope = fetch_page(page)
            rows, total_records = rows_from_envelope(envelope)
            
            if not rows:
                break

            kept = [r for r in rows if keyword_matches(r, needles)] if needles else rows
            state["rows"].extend(kept)
            state["last_page_fetched"] = page
            print(
                f"  +{len(rows)} raw, +{len(kept)} kept "
                f"(running {len(state['rows'])}; server total {total_records})",
                flush=True,
            )
            # import ipdb;ipdb.set_trace()
            # Flush after every listing page — incremental safety against
            # rate-limit blocks during multi-page runs.
            flush(state)

            if max_pages is not None and page >= max_pages:
                break
            if total_records and page * PAGE_SIZE >= total_records:
                break
            if len(rows) < PAGE_SIZE:
                break

            page += 1
            time.sleep(SLEEP_BETWEEN_PAGES_S)
    except KeyboardInterrupt:
        print(
            f"\n[abort] interrupted at page {page}; preserving {len(state['rows'])} rows",
            flush=True,
        )
        flush(state)
        raise

    return len(state["rows"]), json_path, csv_path


def main(argv: list[str] | None = None) -> int:
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--max-pages", type=int, default=None,
                    help="limit pages fetched (default: all available)")
    ap.add_argument("--start-page", type=int, default=None,
                    help="manual override of the starting page (default: auto-resume from existing JSON)")
    ap.add_argument("--no-resume", action="store_true",
                    help="ignore any existing results_<date>.json and start from page 1")
    ap.add_argument("--keyword", default=DEFAULT_KEYWORD,
                    help=f"comma-separated keywords; rows whose Description doesn't match any "
                         f"keyword (case-insensitive substring) are dropped before persistence. "
                         f"Empty string disables the filter. Default: {DEFAULT_KEYWORD!r}")
    ap.add_argument("--lodged-from", default=DEFAULT_LODGED_FROM,
                    help=f"YYYY-MM-DD or dd/MM/yyyy; sent to the server as LodgedDateStart. "
                         f"Empty string disables the date floor. Default: {DEFAULT_LODGED_FROM!r}")
    args = ap.parse_args(argv)

    try:
        count, jp, cp = harvest(
            max_pages=args.max_pages,
            start_page=args.start_page,
            resume=not args.no_resume,
            keyword=args.keyword,
            lodged_from=args.lodged_from,
        )
    except Exception as e:
        print(f"[error] {type(e).__name__}: {e}", file=sys.stderr, flush=True)
        return 1
    print(f"[done] {count} rows -> {jp}", flush=True)
    print(f"[done] {count} rows -> {cp}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
